# Aurora Invitation Link web client module
Creates invitation link upon creating user in admin panel, and allows registering new user account with this link.

# License
This module is licensed under AGPLv3 license if free version of the product is used or AfterLogic Software License if commercial version of the product was purchased.
