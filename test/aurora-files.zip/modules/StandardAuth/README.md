# Aurora Standard Auth module
This module provides API for authentication by login/password that relies on database.

# License
This module is licensed under AGPLv3 license if free version of the product is used or AfterLogic Software License if commercial version of the product was purchased.